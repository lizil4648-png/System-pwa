let stats = JSON.parse(localStorage.getItem("stats")) || {
  str: 10,
  agi: 10,
  vit: 10,
  int: 10
};

function updateStats() {
  for (let key in stats) {
    document.getElementById(key).textContent = stats[key];
  }
  localStorage.setItem("stats", JSON.stringify(stats));
}

function showTab(tabId) {
  document.querySelectorAll(".tab").forEach(tab => tab.classList.remove("active"));
  document.getElementById(tabId).classList.add("active");
}

// Генерация заданий
let quests = JSON.parse(localStorage.getItem("quests")) || [];

function generateQuests() {
  const today = new Date().toDateString();
  if (localStorage.getItem("questDate") === today) return; // уже есть на сегодня

  const possibleQuests = [
    "Сделай 10 отжиманий",
    "Прочитай 5 страниц книги",
    "Сделай 20 приседаний",
    "Прогуляйся 15 минут",
    "Выучи 5 новых слов"
  ];

  quests = [];
  for (let i = 0; i < 3; i++) {
    const quest = {
      text: possibleQuests[Math.floor(Math.random() * possibleQuests.length)],
      done: false
    };
    quests.push(quest);
  }
  localStorage.setItem("quests", JSON.stringify(quests));
  localStorage.setItem("questDate", today);
}

function renderQuests() {
  const container = document.getElementById("questList");
  container.innerHTML = "";
  quests.forEach((q, index) => {
    const div = document.createElement("div");
    div.className = "quest";
    div.innerHTML = `<p>${q.text}</p>`;
    if (!q.done) {
      const btn = document.createElement("button");
      btn.textContent = "Выполнено";
      btn.onclick = () => completeQuest(index);
      div.appendChild(btn);
    } else {
      div.innerHTML += "<p>✔ Выполнено</p>";
    }
    container.appendChild(div);
  });
}

function completeQuest(index) {
  quests[index].done = true;
  // шанс награды
  if (Math.random() < 0.8) {
    const keys = Object.keys(stats);
    const stat = keys[Math.floor(Math.random() * keys.length)];
    stats[stat]++;
    alert(`+1 к ${stat.toUpperCase()}!`);
    updateStats();
  } else {
    alert("🎁 Ты получил награду!");
  }
  localStorage.setItem("quests", JSON.stringify(quests));
  renderQuests();
}

generateQuests();
updateStats();
renderQuests();
